package com.training.collection;


public class Car implements Automobile{
	
	private String registrationNumber;
	
	private String model;
	
	private String brand;
	
	public Car() {
		
		
	}
	
	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public String getModel() {
		return model;
	}

	public String getBrand() {
		return brand;
	}

	public Car(String registrationNumber,String brand,String model) {
		
		this.registrationNumber = registrationNumber;
		this.brand = brand;
		this.model = model;
	}
	
	public void applyBrake() {
		
		System.out.println("Brake applied in car");
		
	}

	public void applyAccelarate() {
		
		System.out.println("Accelaration applied in car");
		
				
	}
	
	
	public boolean equals(Object obj) {
		System.out.println("inside equals() Called by set");
		
		Car car = (Car)obj;
		
		boolean isEqual = false;
		
		if((this.registrationNumber.equals( car.registrationNumber)) && (this.brand.equals( car.brand)) && (this.model.equals(car.model))) {
			
			isEqual =true;
		}
		
		
		return isEqual;
	}
	
	
	public String toString() {
		
		String details = null;
		
		details = "This is a "+ brand + " Car with " +model+ " model."+ " It's registration number is "+registrationNumber;
		
		return details;
	}

	@Override
	public int hashCode() {
		System.out.println("inside hashcode() Called by set");
		final int prime = 31;
		int result = 1;
		result = prime * result + ((registrationNumber == null) ? 0 : registrationNumber.hashCode());
		return result;
	}
/*
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Car other = (Car) obj;
		if (registrationNumber == null) {
			if (other.registrationNumber != null)
				return false;
		} else if (!registrationNumber.equals(other.registrationNumber))
			return false;
		return true;
	}*/
	
}
