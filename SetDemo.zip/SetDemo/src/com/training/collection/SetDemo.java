package com.training.collection;

import java.util.HashSet;
import java.util.Set;

public class SetDemo {
	
	
	public static void main(String arg[]) {
			
		
		
		boolean[] b =new boolean[4];
		
		Set s = new HashSet<Car>();
		
		b[0] = s.add(new Car("TN223344","Hyundai","i10"));
		
		b[1] = s.add(new Car("PY223354","Honda","city"));
		
		b[2] = s.add(new Car("KL223356","Maruti","Swift"));		
		
		
		b[3] = s.add(new Car("KL223356","Maruti","Swift"));
		
		for (int i=0; i<b.length; i++) {
			
			System.out.println("Value inside boolean array:"+b[i]);
		}
	
	for(Object o:s) {
		
		System.out.println("Value inside Set:"+o);
	}

}
}
