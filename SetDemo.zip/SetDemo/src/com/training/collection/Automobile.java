package com.training.collection;


public interface Automobile {
	
		
	public void applyBrake();
	
	public void applyAccelarate();
}
